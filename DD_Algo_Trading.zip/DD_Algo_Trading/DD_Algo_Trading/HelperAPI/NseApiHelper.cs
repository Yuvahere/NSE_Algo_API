﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DD_Algo_Trading.HelperAPI
{
    public class NseApiHelper
    {

        public async Task<string> GetNSENiftyFeed()
        {
            try
            {
                var client = new RestClient("https://www.nseindia.com/api/option-chain-indices?symbol=NIFTY");

                RestRequest request = new RestRequest();
                request.AddHeader("Accept", "*/*");
                request.AddHeader("Connection", "keep-alive");
                request.AddHeader("Accept-Encoding", "gzip, deflate, br");
                request.AddHeader("Accept-Language", "en-US,en;q=0.9,hi;q=0.8");
                request.AddHeader("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");

                //request.AddHeader("Content-Type", "application/json");
                //request.AddHeader("Accept", "application/json");
                var response = await client.ExecuteAsync(request);


                return string.Empty;

            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
