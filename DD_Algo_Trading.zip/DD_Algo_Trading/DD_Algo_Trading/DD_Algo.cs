﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DD_Algo_Trading.HelperAPI;

namespace DD_Algo_Trading
{
    public partial class DD_Algo : Form
    {
        public DD_Algo()
        {
            InitializeComponent();
        }

        private void btnGetNiftyOptions_Click(object sender, EventArgs e)
        {
            NseApiHelper nseHelper = new NseApiHelper();

            var result = nseHelper.GetNSENiftyFeed();
            //var result = nseHelper.GetNSENiftyFeed().Result; // Restsharp doesn't like .Result

            // Don't know for some strange reason, the Result is creating the deadlock.

        }
    }
}
